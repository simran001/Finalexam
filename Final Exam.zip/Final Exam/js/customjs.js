
  fetch('header.html')
  .then(response => response.text())
  .then(html => {
    const headerElement = document.getElementById('header');
    headerElement.innerHTML =html;
  });
  fetch('footer.html')
  .then(response => response.text())
  .then(html => {
    const headerElement = document.getElementById('footer');
    headerElement.innerHTML =html;
  });